wikibase.lexeme.widgets = wikibase.lexeme.widgets || {};
