wikibase.lexeme.datamodel = wikibase.lexeme.datamodel || {};
