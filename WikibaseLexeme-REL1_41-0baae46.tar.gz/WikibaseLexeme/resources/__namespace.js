wikibase.lexeme = wikibase.lexeme || {};
