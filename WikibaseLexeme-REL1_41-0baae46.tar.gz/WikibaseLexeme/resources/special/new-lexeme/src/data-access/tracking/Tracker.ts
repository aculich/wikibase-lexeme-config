export default interface Tracker {
	increment( name: string ): void;
}
