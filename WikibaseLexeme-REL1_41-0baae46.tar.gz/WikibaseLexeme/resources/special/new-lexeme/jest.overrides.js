( function () {
	// eslint-disable-next-line no-console
	console.warn = function () {
		// ignore @vue/compat warnings
	};
}() );
